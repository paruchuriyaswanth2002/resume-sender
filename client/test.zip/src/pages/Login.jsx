const ERRORS = {
  denied: 'Google sign-in was cancelled.',
  state: 'Sign-in expired. Please try again.',
  not_allowed: 'This Google account is not allowed to use this app.',
  scope: 'Permission to send email was not granted. Tick the "Send email on your behalf" box and try again.',
  oauth: 'Sign-in failed. Please try again.',
};

export default function Login() {
  const code = new URLSearchParams(window.location.search).get('error');
  return (
    <div className="login">
      <div className="login-card">
        <h1>Resume Sender</h1>
        <p className="lead">Send your resume to each recruiter as its own email, from your own Gmail.</p>
        {code && (
          <p className="banner bad" role="alert">
            {ERRORS[code] || 'Something went wrong. Please try again.'}
          </p>
        )}
        <a className="btn primary" href="/api/auth/google">
          Sign in with Google
        </a>
        <p className="fine">
          The app asks Google only for permission to send email on your behalf. It cannot read your inbox.
        </p>
      </div>
    </div>
  );
}
