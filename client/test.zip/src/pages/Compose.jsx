import { useMemo, useState } from 'react';
import { api } from '../api.js';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

// One recipient per line: email, name, company  (name and company are optional)
function parseRecipients(text) {
  const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const seen = new Set();
  const valid = [];
  const invalid = [];
  let duplicates = 0;

  lines.forEach((line, i) => {
    const parts = line.split(/[,\t;]/).map((p) => p.trim().replace(/^"|"$/g, ''));
    const email = (parts[0] || '').toLowerCase();
    if (i === 0 && email === 'email') return; // CSV header row
    if (!EMAIL_RE.test(email)) return invalid.push(line);
    if (seen.has(email)) return duplicates++;
    seen.add(email);
    valid.push({ email, name: parts[1] || '', company: parts[2] || '' });
  });
  return { valid, invalid, duplicates };
}

const fill = (text, r) =>
  text.replace(/\{\{\s*(name|company)\s*\}\}/gi, (_, k) =>
    k.toLowerCase() === 'name' ? r.name || 'there' : r.company || 'your company'
  );

export default function Compose({ user, onCreated }) {
  const { maxRecipients, maxPdfMb } = user.limits;
  const [recipientText, setRecipientText] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [file, setFile] = useState(null);
  const [step, setStep] = useState('edit');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const parsed = useMemo(() => parseRecipients(recipientText), [recipientText]);
  const remainingToday = Math.max(user.limits.dailyLimit - user.sentToday, 0);

  const problems = [];
  if (parsed.valid.length === 0) problems.push('Add at least one recipient.');
  if (parsed.valid.length > maxRecipients) problems.push(`Limit is ${maxRecipients} recipients per send.`);
  if (parsed.valid.length > remainingToday) problems.push(`Only ${remainingToday} sends left in the last 24 hours.`);
  if (parsed.invalid.length) problems.push('Fix or remove the invalid addresses.');
  if (!subject.trim()) problems.push('Add a subject.');
  if (!body.trim()) problems.push('Write a message.');
  if (!file) problems.push('Attach your resume as a PDF.');
  else if (!/\.pdf$/i.test(file.name)) problems.push('Resume must be a PDF.');
  else if (file.size > maxPdfMb * 1024 * 1024) problems.push(`Resume must be under ${maxPdfMb} MB.`);

  const importCsv = async (e) => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f) return;
    const text = await f.text();
    setRecipientText((prev) => (prev.trim() ? `${prev.trim()}\n${text.trim()}` : text.trim()));
  };

  const send = async () => {
    setBusy(true);
    setError('');
    try {
      const form = new FormData();
      form.append('subject', subject);
      form.append('body', body);
      form.append('recipients', JSON.stringify(parsed.valid));
      form.append('resume', file);
      const { id } = await api.create(form);
      onCreated(id);
    } catch (err) {
      const extra = err.details?.invalid?.length ? `: ${err.details.invalid.join(', ')}` : '';
      setError(err.message + extra);
      setStep('edit');
    } finally {
      setBusy(false);
    }
  };

  if (step === 'preview') {
    const first = parsed.valid[0];
    return (
      <section className="panel narrow">
        <h2>Check before sending</h2>
        <dl className="facts">
          <dt>From</dt>
          <dd>{user.email}</dd>
          <dt>To</dt>
          <dd>
            {parsed.valid.length} separate emails, one per recipient. Nobody sees anyone else.
          </dd>
          <dt>Attachment</dt>
          <dd>{file.name}</dd>
        </dl>
        <p className="muted">Example for {first.email}</p>
        <div className="mail">
          <div className="mail-subject">{fill(subject, first)}</div>
          <pre>{fill(body, first)}</pre>
        </div>
        {error && <p className="banner bad" role="alert">{error}</p>}
        <div className="row">
          <button className="btn" onClick={() => setStep('edit')} disabled={busy}>
            Back to edit
          </button>
          <button className="btn primary" onClick={send} disabled={busy}>
            {busy ? 'Starting…' : `Send ${parsed.valid.length} email${parsed.valid.length === 1 ? '' : 's'}`}
          </button>
        </div>
      </section>
    );
  }

  return (
    <section className="panel narrow">
      <h2>New send</h2>

      <label htmlFor="recipients">Recipients</label>
      <textarea
        id="recipients"
        rows={7}
        value={recipientText}
        onChange={(e) => setRecipientText(e.target.value)}
        placeholder={'one per line:\nrecruiter@company.com, Priya, Acme\nhr@startup.io'}
      />
      <div className="row between">
        <span className="muted" aria-live="polite">
          {parsed.valid.length} valid
          {parsed.duplicates > 0 && `, ${parsed.duplicates} duplicate${parsed.duplicates > 1 ? 's' : ''} removed`}
          {parsed.invalid.length > 0 && `, ${parsed.invalid.length} invalid`} (max {maxRecipients})
        </span>
        <label className="btn small file">
          Import CSV
          <input type="file" accept=".csv,.txt,text/csv,text/plain" onChange={importCsv} hidden />
        </label>
      </div>
      {parsed.invalid.length > 0 && (
        <p className="banner bad">Invalid: {parsed.invalid.slice(0, 5).join(' | ')}{parsed.invalid.length > 5 ? ' …' : ''}</p>
      )}

      <label htmlFor="subject">Subject</label>
      <input id="subject" value={subject} onChange={(e) => setSubject(e.target.value)} maxLength={200} />

      <label htmlFor="body">Message</label>
      <textarea
        id="body"
        rows={10}
        value={body}
        onChange={(e) => setBody(e.target.value)}
        placeholder={'Hi {{name}},\n\nI am a full-stack developer interested in roles at {{company}}...'}
      />
      <p className="muted">
        {'{{name}}'} and {'{{company}}'} are filled in per recipient from the second and third columns.
      </p>

      <label htmlFor="resume">Resume (PDF, up to {maxPdfMb} MB)</label>
      <input id="resume" type="file" accept="application/pdf,.pdf" onChange={(e) => setFile(e.target.files?.[0] || null)} />

      {error && <p className="banner bad" role="alert">{error}</p>}
      {problems.length > 0 && <p className="muted">{problems[0]}</p>}

      <div className="row">
        <button className="btn primary" disabled={problems.length > 0 || user.gmailStatus !== 'connected'} onClick={() => setStep('preview')}>
          Preview
        </button>
        <span className="muted">
          {user.sentToday} of {user.limits.dailyLimit} sent in the last 24 hours
        </span>
      </div>
    </section>
  );
}
