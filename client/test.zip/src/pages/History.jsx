import { useCallback, useEffect, useState } from 'react';
import { api } from '../api.js';

const LABEL = { pending: 'Pending', sending: 'Sending', sent: 'Sent', failed: 'Failed' };
const when = (d) => new Date(d).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });

export default function History({ selectedId, onSelect, onChanged }) {
  const [list, setList] = useState([]);
  const [detail, setDetail] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const loadList = useCallback(
    () => api.campaigns().then((d) => setList(d.campaigns)).catch((e) => setError(e.message)),
    []
  );
  const loadDetail = useCallback(
    (id) => api.campaign(id).then(setDetail).catch((e) => setError(e.message)),
    []
  );

  useEffect(() => {
    loadList();
  }, [loadList]);

  useEffect(() => {
    if (selectedId) loadDetail(selectedId);
    else setDetail(null);
  }, [selectedId, loadDetail]);

  // Poll only while something is actually sending
  const active = list.some((c) => c.status === 'running') || detail?.campaign.status === 'running';
  useEffect(() => {
    if (!active) return undefined;
    const t = setInterval(() => {
      loadList();
      if (selectedId) loadDetail(selectedId);
      onChanged?.();
    }, 3000);
    return () => clearInterval(t);
  }, [active, selectedId, loadList, loadDetail, onChanged]);

  const messages = detail?.messages || [];
  const count = (s) => messages.filter((m) => m.status === s).length;
  const retryable =
    messages.filter((m) => m.status === 'failed' && m.errorCategory !== 'invalid').length + count('pending');

  const retry = async () => {
    setBusy(true);
    setError('');
    try {
      await api.retry(selectedId);
      await Promise.all([loadDetail(selectedId), loadList()]);
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!window.confirm('Delete this send, its recipient list, and the stored resume?')) return;
    setBusy(true);
    setError('');
    try {
      await api.remove(selectedId);
      onSelect(null);
      await loadList();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="history">
      <aside className="panel list" aria-label="Past sends">
        <h2>Sends</h2>
        {list.length === 0 && <p className="muted">Nothing sent yet. Start with New send.</p>}
        <ul>
          {list.map((c) => (
            <li key={c.id}>
              <button className={c.id === selectedId ? 'item on' : 'item'} onClick={() => onSelect(c.id)}>
                <span className="item-title">{c.subject}</span>
                <span className="muted">
                  {when(c.createdAt)}: {c.counts.sent} of {c.total} sent
                  {c.counts.failed > 0 && `, ${c.counts.failed} failed`}
                  {c.status === 'running' && ', sending'}
                </span>
              </button>
            </li>
          ))}
        </ul>
      </aside>

      <section className="panel detail">
        {error && <p className="banner bad" role="alert">{error}</p>}
        {!detail && <p className="muted">Select a send to see each recipient's status.</p>}
        {detail && (
          <>
            <h2>{detail.campaign.subject}</h2>
            <p className="muted">
              {when(detail.campaign.createdAt)}. Attachment: {detail.campaign.attachment.filename}
            </p>
            <p>
              <strong>{count('sent')}</strong> sent, <strong>{count('failed')}</strong> failed,{' '}
              <strong>{count('pending') + count('sending')}</strong> waiting
              {detail.campaign.status === 'paused' && ' (paused)'}
            </p>

            <div className="strip" role="img" aria-label="One block per recipient, colored by status">
              {messages.map((m) => (
                <span key={m._id} className={`blk ${m.status}`} title={`${m.email}: ${LABEL[m.status]}`} />
              ))}
            </div>

            <div className="row">
              {detail.campaign.status !== 'running' && retryable > 0 && (
                <button className="btn primary" onClick={retry} disabled={busy}>
                  Retry {retryable} unsent
                </button>
              )}
              {detail.campaign.status !== 'running' && (
                <button className="btn danger" onClick={remove} disabled={busy}>
                  Delete
                </button>
              )}
            </div>

            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Recipient</th>
                    <th>Status</th>
                    <th>Note</th>
                  </tr>
                </thead>
                <tbody>
                  {messages.map((m) => (
                    <tr key={m._id}>
                      <td>
                        {m.email}
                        {(m.name || m.company) && (
                          <span className="muted"> {[m.name, m.company].filter(Boolean).join(', ')}</span>
                        )}
                      </td>
                      <td>
                        <span className={`pill ${m.status}`}>{LABEL[m.status]}</span>
                      </td>
                      <td className="muted">
                        {m.status === 'sent' && m.sentAt ? when(m.sentAt) : m.errorMessage || ''}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </section>
    </div>
  );
}
