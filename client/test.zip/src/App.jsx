import { useCallback, useEffect, useState } from 'react';
import { api } from './api.js';
import Login from './pages/Login.jsx';
import Compose from './pages/Compose.jsx';
import History from './pages/History.jsx';

export default function App() {
  const [user, setUser] = useState(undefined); // undefined = loading, null = signed out
  const [view, setView] = useState('compose');
  const [selectedId, setSelectedId] = useState(null);

  const refreshUser = useCallback(
    () => api.me().then(setUser).catch(() => setUser(null)),
    []
  );

  useEffect(() => {
    refreshUser();
  }, [refreshUser]);

  if (user === undefined) return <div className="boot">Loading…</div>;
  if (!user) return <Login />;

  const signOut = async () => {
    await api.logout().catch(() => {});
    setUser(null);
  };

  return (
    <div className="shell">
      <header className="topbar">
        <strong className="brand">Resume Sender</strong>
        <nav aria-label="Main">
          <button className={view === 'compose' ? 'tab on' : 'tab'} onClick={() => setView('compose')}>
            New send
          </button>
          <button className={view === 'history' ? 'tab on' : 'tab'} onClick={() => setView('history')}>
            History
          </button>
        </nav>
        <div className="who">
          <span title={user.email}>{user.email}</span>
          <button className="link" onClick={signOut}>
            Sign out
          </button>
        </div>
      </header>

      {user.gmailStatus === 'revoked' && (
        <div className="banner bad" role="alert">
          Gmail access was revoked or expired. <a href="/api/auth/google">Sign in with Google again</a> to reconnect.
        </div>
      )}

      <main>
        {view === 'compose' ? (
          <Compose
            user={user}
            onCreated={(id) => {
              setSelectedId(id);
              setView('history');
              refreshUser();
            }}
          />
        ) : (
          <History selectedId={selectedId} onSelect={setSelectedId} onChanged={refreshUser} />
        )}
      </main>
    </div>
  );
}
